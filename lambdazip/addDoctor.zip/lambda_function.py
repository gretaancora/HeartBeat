import os
import json
import logging
import boto3
from botocore.exceptions import ClientError
import hmac
import hashlib
import base64

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Read configuration from environment
USER_POOL_ID      = os.environ.get('USER_POOL_ID')
APP_CLIENT_ID     = os.environ.get('APP_CLIENT_ID')
APP_CLIENT_SECRET = os.environ.get('APP_CLIENT_SECRET')  # può essere None se il client non ha secret
DOCTOR_GROUP      = os.environ.get('DOCTOR_GROUP', 'Doctor')
AWS_REGION        = os.environ.get('REGION')

# Check required config
if not USER_POOL_ID or not APP_CLIENT_ID:
    logger.error("Missing USER_POOL_ID or APP_CLIENT_ID in environment variables")
    raise RuntimeError("USER_POOL_ID and APP_CLIENT_ID must be set")

# Initialize AWS Cognito Identity Provider client
cognito_client = boto3.client('cognito-idp', region_name=AWS_REGION)

# CORS headers
CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',  # metti qui il tuo dominio di produzione
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'OPTIONS,POST'
}

def get_secret_hash(username: str) -> str:
    """
    Compute the secret hash for Cognito calls on a client with a secret.
    """
    message = username + APP_CLIENT_ID
    dig = hmac.new(
        APP_CLIENT_SECRET.encode('utf-8'),
        msg=message.encode('utf-8'),
        digestmod=hashlib.sha256
    ).digest()
    return base64.b64encode(dig).decode()

def lambda_handler(event, context):
    # Handle CORS preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': ''
        }

    # Log incoming event for debugging
    logger.info(f"Received event: {json.dumps(event)}")

    # Parse JSON body
    try:
        body = json.loads(event.get('body', '{}'))
    except json.JSONDecodeError:
        logger.error("Invalid JSON format in request body")
        return {
            'statusCode': 400,
            'headers': CORS_HEADERS,
            'body': json.dumps({'message': 'Invalid JSON'})
        }

    email = body.get('email')
    password = body.get('password')

    if not email or not password:
        logger.error("Missing required parameters: email or password")
        return {
            'statusCode': 400,
            'headers': CORS_HEADERS,
            'body': json.dumps({'message': 'Both email and password are required'})
        }

    try:
        signup_kwargs = {
            'ClientId': APP_CLIENT_ID,
            'Username': email,
            'Password': password,
            'UserAttributes': [{'Name': 'email', 'Value': email}]
        }

        # If the client has a secret, calcola e invia il SecretHash
        if APP_CLIENT_SECRET:
            secret_hash = get_secret_hash(email)
            signup_kwargs['SecretHash'] = secret_hash
            logger.debug("Using SecretHash in sign_up")

        # Sign up the user
        cognito_client.sign_up(**signup_kwargs)
        logger.info(f"Sign-up initiated for {email}")

        # Auto-confirm the user
        cognito_client.admin_confirm_sign_up(
            UserPoolId=USER_POOL_ID,
            Username=email
        )
        logger.info(f"User {email} auto-confirmed")

        # Add the user to the 'Doctor' group
        cognito_client.admin_add_user_to_group(
            UserPoolId=USER_POOL_ID,
            Username=email,
            GroupName=DOCTOR_GROUP
        )
        logger.info(f"User {email} added to group {DOCTOR_GROUP}")

        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'message': f'User {email} registered, confirmed, and added to group {DOCTOR_GROUP}'
            })
        }

    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_msg  = e.response['Error']['Message']
        logger.error(f"Cognito error ({error_code}): {error_msg}")

        # Gestione di errori specifici
        if error_code == 'ResourceNotFoundException':
            user_msg = 'Configuration error: user pool or app client not found'
            status   = 500
        elif error_code == 'UsernameExistsException':
            user_msg = 'This email is already registered'
            status   = 400
        else:
            user_msg = 'Internal server error'
            status   = 500

        return {
            'statusCode': status,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'message': user_msg,
                'error': error_msg
            })
        }
