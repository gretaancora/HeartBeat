import os
import json
import logging
import boto3
from botocore.exceptions import ClientError
import hmac
import hashlib
import base64

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Read configuration from environment
USER_POOL_ID         = os.environ.get('USER_POOL_ID')
APP_CLIENT_ID        = os.environ.get('APP_CLIENT_ID')
APP_CLIENT_SECRET    = os.environ.get('APP_CLIENT_SECRET')  # può essere None se il client non ha secret
DOCTOR_GROUP         = os.environ.get('DOCTOR_GROUP', 'Doctor')
AWS_REGION           = os.environ.get('REGION')
ANOMALY_TOPIC_ARN    = os.environ.get('ANOMALY_TOPIC_ARN')  # ARN del topic SNS

# Check required config
if not USER_POOL_ID or not APP_CLIENT_ID or not ANOMALY_TOPIC_ARN:
    logger.error("Missing USER_POOL_ID, APP_CLIENT_ID or ANOMALY_TOPIC_ARN in environment variables")
    raise RuntimeError("USER_POOL_ID, APP_CLIENT_ID and ANOMALY_TOPIC_ARN must be set")

# Initialize AWS clients
cognito_client = boto3.client('cognito-idp', region_name=AWS_REGION)
sns_client     = boto3.client('sns', region_name=AWS_REGION)

# CORS headers
CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
    'Access-Control-Allow-Methods': 'OPTIONS,POST'
}

def get_secret_hash(username: str) -> str:
    message = username + APP_CLIENT_ID
    dig = hmac.new(
        APP_CLIENT_SECRET.encode('utf-8'),
        msg=message.encode('utf-8'),
        digestmod=hashlib.sha256
    ).digest()
    return base64.b64encode(dig).decode()

def lambda_handler(event, context):
    # Handle CORS preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS_HEADERS, 'body': ''}

    logger.info(f"Received event: {json.dumps(event)}")
    try:
        body = json.loads(event.get('body', '{}'))
    except json.JSONDecodeError:
        logger.error("Invalid JSON format in request body")
        return {'statusCode': 400, 'headers': CORS_HEADERS, 'body': json.dumps({'message': 'Invalid JSON'})}

    email    = body.get('email')
    password = body.get('password')
    if not email or not password:
        logger.error("Missing required parameters: email or password")
        return {'statusCode': 400, 'headers': CORS_HEADERS, 'body': json.dumps({'message': 'Both email and password are required'})}

    try:
        signup_kwargs = {
            'ClientId': APP_CLIENT_ID,
            'Username': email,
            'Password': password,
            'UserAttributes': [{'Name': 'email', 'Value': email}]
        }
        if APP_CLIENT_SECRET:
            signup_kwargs['SecretHash'] = get_secret_hash(email)
            logger.debug("Using SecretHash in sign_up")

        cognito_client.sign_up(**signup_kwargs)
        logger.info(f"Sign-up initiated for {email}")

        cognito_client.admin_confirm_sign_up(UserPoolId=USER_POOL_ID, Username=email)
        logger.info(f"User {email} auto-confirmed")

        cognito_client.admin_add_user_to_group(
            UserPoolId=USER_POOL_ID,
            Username=email,
            GroupName=DOCTOR_GROUP
        )
        logger.info(f"User {email} added to group {DOCTOR_GROUP}")

        
        filter_policy = json.dumps({ "doctor_id": [email] })
        sns_client.subscribe(
            TopicArn=ANOMALY_TOPIC_ARN,
            Protocol='email',
            Endpoint=email,
            Attributes={'FilterPolicy': filter_policy}
        )
        logger.info(f"SNS subscription created for {email} on topic {ANOMALY_TOPIC_ARN} with filter {filter_policy}")

        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'message': f'User {email} registered, confirmed, added to group {DOCTOR_GROUP} and subscribed to SNS'
            })
        }

    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_msg  = e.response['Error']['Message']
        logger.error(f"Cognito error ({error_code}): {error_msg}")

        if error_code == 'ResourceNotFoundException':
            user_msg, status = 'Configuration error: user pool or app client not found', 500
        elif error_code == 'UsernameExistsException':
            user_msg, status = 'This email is already registered', 400
        else:
            user_msg, status = 'Internal server error', 500

        return {
            'statusCode': status,
            'headers': CORS_HEADERS,
            'body': json.dumps({'message': user_msg, 'error': error_msg})
        }
