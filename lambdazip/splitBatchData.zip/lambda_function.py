import os
import json
import uuid
import boto3
import logging
from botocore.exceptions import ClientError
 
# AWS Clients
s3_client = boto3.client('s3')
dynamo = boto3.client('dynamodb')
sf_client = boto3.client('stepfunctions')
 
# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
 
# Config from env vars
STATE_MACHINE_ARN = os.environ.get('STATE_MACHINE_ARN')
IOT_PATIENT_TABLE = os.environ.get('IOT_PATIENT_TABLE')
PATIENT_TABLE = os.environ.get('PATIENT_TABLE')
 
 
def lambda_handler(event, context):
    logger.debug("<<< ENTER LAMBDA HANDLER >>>")
    logger.debug(f"Raw event: {json.dumps(event)}")
 
    # 1. Extract bucket and key from S3 event
    record0 = event['Records'][0]
    bucket = record0['s3']['bucket']['name']
    key = record0['s3']['object']['key']
 
    # 2. Download and parse the file
    try:
        obj = s3_client.get_object(Bucket=bucket, Key=key)
        payload_json = json.loads(obj['Body'].read())
    except ClientError as e:
        logger.error(f"Error downloading {bucket}/{key}: {e}")
        raise
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in {key}: {e}")
        raise
 
    # 3. Extract deviceId and list of records
    device_id = payload_json.get("deviceId")
    records = payload_json.get("records", [])
    if not device_id or not isinstance(records, list):
        raise ValueError("JSON must contain 'deviceId' and 'records' (list).")
 
    # 4. Retrieve patientId from IoTPatient table, then age and sex from Patient table
    try:
        # Fetch mapping from device to patient
        resp_iot = dynamo.get_item(
            TableName=IOT_PATIENT_TABLE,
            Key={'deviceId': {'S': device_id}}
        )
    except ClientError as e:
        logger.error(f"DynamoDB get_item (IoTPatient) error: {e}")
        raise
 
    item_iot = resp_iot.get('Item')
    if not item_iot or 'patientId' not in item_iot:
        raise KeyError(f"No entry or missing 'patientId' for deviceId={device_id}")
 
    # Extract patientId
    patient_id = item_iot['patientId']['S']
 
    try:
        # Fetch patient details
        resp_pat = dynamo.get_item(
            TableName=PATIENT_TABLE,
            Key={'patientId': {'S': patient_id}}
        )
    except ClientError as e:
        logger.error(f"DynamoDB get_item (Patient) error: {e}")
        raise
 
    item_pat = resp_pat.get('Item')
    if not item_pat:
        raise KeyError(f"No patient record for patientId={patient_id}")
 
    # Extract and convert fields
    sex = item_pat.get('sex', {}).get('S', '').upper()
    age_str = item_pat.get('age', {}).get('N', '0')
    try:
        age = int(age_str)
    except ValueError:
        age = 0
 
    # 5. For each record, start a Step Functions execution
    processed = 0
    for record in records:
        try:
            ts, bpm_values = record
        except (ValueError, TypeError):
            logger.warning(f"Malformed record: {record}, skipping.")
            continue
 
        sf_payload = {
            "deviceId": device_id,
            "patientId": patient_id,
            "age": age,
            "sex": sex,
            "bpm_values": bpm_values,
            "ts": str(ts)
        }
 
        execution_name = f"{device_id}-{uuid.uuid4()}"
        try:
            sf_client.start_execution(
                stateMachineArn=STATE_MACHINE_ARN,
                name=execution_name,
                input=json.dumps(sf_payload)
            )
            logger.info(f"Triggered execution {execution_name}")
        except ClientError as e:
            code = e.response.get('Error', {}).get('Code')
            # Ignore duplicates, rethrow others
            if code != 'ExecutionAlreadyExists':
                logger.error(f"Error start_execution {execution_name}: {e}")
                raise
            else:
                logger.warning(f"ExecutionAlreadyExists for {execution_name}")
 
        processed += 1
 
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Processing complete",
            "deviceId": device_id,
            "records_processed": processed
        })
    }