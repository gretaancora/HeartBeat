import os
import json
import boto3
import logging
from botocore.exceptions import ClientError

# Client AWS
dynamo = boto3.client('dynamodb')
sfn    = boto3.client('stepfunctions')

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Configurazione da env vars
IOT_PATIENT_TABLE  = os.environ.get('IOT_PATIENT_TABLE')
PATIENT_TABLE      = os.environ.get('PATIENT_TABLE')
STATE_MACHINE_ARN  = os.environ.get('STATE_MACHINE_ARN')

if not IOT_PATIENT_TABLE or not PATIENT_TABLE:
    raise RuntimeError("Le tabelle DynamoDB non sono configurate: verificare IOT_PATIENT_TABLE e PATIENT_TABLE")


def lambda_handler(event, context):
    """
    AWS Lambda handler che processa un evento SQS con più records,
    avvia esecuzioni di Step Functions e restituisce un JSON in output.

    In output, restituisce per ciascun record:
      - patient_id: str
      - bpm_values: List[float]
      - age: int
      - sex: str

    Output (JSON string):
    {
      "statusCode": 200,
      "processed": [
        {
          "patient_id": "...",
          "bpm_values": [...],
          "age": 30,
          "sex": "M"
        },
        ...
      ]
    }
    """
    print(">>> ENTER LAMBDA HANDLER <<<")
    logger.error(">>> ENTER LAMBDA HANDLER <<<")
    logger.error(f"Raw event all’inizio: {json.dumps(event)}")

    results = []
    batch_failures = []

    if not STATE_MACHINE_ARN:
        raise RuntimeError("STATE_MACHINE_ARN non configurato")

    for record in event.get('Records', []):
        msg_id = record.get('messageId')
        try:
            body = json.loads(record.get('body', '{}'))
            device_id = body.get('deviceId')

            # Recupera mapping device->patientId
            db = dynamo.get_item(
                TableName=IOT_PATIENT_TABLE,
                Key={'deviceId': {'S': device_id}}
            )
            if 'Item' not in db:
                raise KeyError(f"Device {device_id} non trovato in DynamoDB")
            item = db['Item']
            patient_id = item['patientId']['S']

            # Recupera age e sex dalla tabella Patient
            dbp = dynamo.get_item(
                TableName=PATIENT_TABLE,
                Key={'patientId': {'S': patient_id}}
            )
            if 'Item' not in dbp:
                raise KeyError(f"patientId {patient_id} non trovato in PATIENT_TABLE")
            pitem = dbp['Item']
            sex = pitem.get('sex', {}).get('S', '').upper()
            age_str = pitem.get('age', {}).get('N', '0')
            try:
                age = int(age_str)
            except ValueError:
                age = 0

            bpm_values = body.get('bpm_values', [])

            payload = {
                "deviceId":   device_id,
                "patientId":  patient_id,
                "age":        age,
                "sex":        sex,
                "bpm_values": bpm_values,
                "ts":         str(body.get('ts', ''))
            }
            exec_name = f"{device_id}-{payload['ts']}"
            try:
                sfn.start_execution(
                    stateMachineArn=STATE_MACHINE_ARN,
                    name=exec_name,
                    input=json.dumps(payload)
                )
            except ClientError as e:
                if e.response.get('Error', {}).get('Code') != 'ExecutionAlreadyExists':
                    raise

            results.append({
                'patientId': patient_id,
                'bpm_values': bpm_values,
                'age': age,
                'sex': sex,
                'ts': str(body.get('ts', ''))
            })

        except Exception as e:
            print(f"Errore processing record {record.get('messageId')}: {e}")
            batch_failures.append({ 'itemIdentifier': msg_id })
            results.append({
                'patient_id': item.get('patientId', {}).get('S', 'unknown') if 'item' in locals() else 'unknown',
                'error': str(e)
            })

    return {
        'statusCode': 200,
        'processed': results,
        'batchItemFailures': batch_failures
    }
